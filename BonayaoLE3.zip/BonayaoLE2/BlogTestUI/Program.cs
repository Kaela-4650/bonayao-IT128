﻿using BlogDataLibrary.Database;
using BlogDataLibrary.Data;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using BlogDataLibrary.Models;
using System.Runtime.CompilerServices;

namespace BlogTestUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlData db = GetConnection();

            Console.WriteLine("1. Login");
            Console.WriteLine("2. Register");
            Console.WriteLine("3. Show Post Detail");
            Console.Write("Select an option: ");
            string option = Console.ReadLine();

            if (option =="1")
            {
                Authenticate(db);
            }
            else if (option == "2")
            {
                Register(db);
            }
            else if (option == "3")
            {
                ShowPostDetail(db);
            }

            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        }

        public static void Register(SqlData db)
        {
            Console.Write("Enter new username: ");
            string username = Console.ReadLine();

            Console.Write("Enter new password: ");
            string password = Console.ReadLine();

            Console.Write("Enter first Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Enter last Name: ");
            string lastName = Console.ReadLine();
            
            db.Register(username, firstName, lastName, password);
            Console.WriteLine("User registered successfully!");
        }

        private static UserModel GetCurrentUser (SqlData db)
        {
            Console.Write("Username: ");
            string username = Console.ReadLine();

            Console.Write("Password: ");
            string password = Console.ReadLine();

            UserModel user = db.Authenticate(username, password);
            
            return user;
        }

        public static void Authenticate(SqlData db)
        {
            UserModel user = GetCurrentUser(db);

            if (user == null)
            {
                Console.WriteLine("Invalid credentials.");
            }
            else
            {
                Console.WriteLine($"Welcome, {user.UserName}");

                Console.WriteLine("1. Add a post: ");
                Console.WriteLine("2. List all posts: ");
                Console.Write("Select an option: ");
                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    AddPost(db, user);
                }
                else if (choice == "2")
                {
                    ListPost(db);
                }
            }
        }

        private static void AddPost(SqlData db, UserModel user)
        {
            Console.Write("Title: ");
            string title = Console.ReadLine();

            Console.Write("Write Body: ");
            string body = Console.ReadLine();

            PostModel post = new PostModel
            {
                Title = title,
                Body = body,
                DateCreated = DateTime.Now,
                UserId = user.Id
            };

            db.AddPost(post);
            Console.WriteLine("Post added successfully!");
        }

        private static void ListPost(SqlData db)
        {
            List<ListPostModel> posts = db.ListPosts();

            foreach (ListPostModel post in posts)
            {
                Console.WriteLine($"{post.Id}. Title: {post.Title} by {post.UserName} [{post.DateCreated.ToString("yyyy-MM-dd")}]");
                Console.WriteLine($"{post.Body.Substring(0, 20)}...");
                Console.WriteLine();
            }
        }

        private static void ShowPostDetail(SqlData db)
        {
            Console.Write("Enter a Post ID: ");
            int id = Int32.Parse(Console.ReadLine());

            ListPostModel post = db.ShowPostDetail(id);
            Console.WriteLine(post.Title);
            Console.WriteLine($"by {post.FirstName} {post.LastName} [{post.UserName}]");

            Console.WriteLine();

            Console.WriteLine(post.Body);

            Console.WriteLine(post.DateCreated.ToString("MMM d yyyy"));

        }

            static SqlData GetConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();
            ISqlDataAccess dbAccess = new SqlDataAccess(config);
            SqlData db = new SqlData(dbAccess);

            return db;
        }
    }
}
